import csv

fn = input("File name:")
file = open(fn)
fi = file.readlines()
print(fi)
file.close()





