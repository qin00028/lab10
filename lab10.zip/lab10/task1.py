import os
g = open("2000_GirlsNames.txt", "r")
g2 = open("2000_GirlsNames.csv", "w")
b = open("2000_BoysNames.txt", "r")
b2 = open("2000_BoyNames.csv", "w")
g2.write("First name,Count\n")
b2.write("First name,Count\n")
while True:
    line = g.readline()
    print(line)
    if line == "":
        break
    if line.find(',') > 0:
        g2.write(line)
        continue
while True:
    line = b.readline()
    print(line)
    if line == "":
        break
    if line.find(',') > 0:
        b2.write(line)
        continue
g.close()
g2.close()
b.close()
b2.close()
