
import click
from PIL import Image, ImageFont, ImageDraw
from gfxhat import lcd,  fonts

def generateDictionary():
    font = open('font3.txt','r')
    charList = []
    while True:
        line1 = font.readline()
        if line1 == "":
            break
        else:
            line1 = line1.replace("\n","").split(",")
        c = line1[1]
        value = hex2bin(line1[0])
        list = []
        for i in range(0, 8):
            for a in range(0, 8):
                list.append(int(value[i * 8 + a]))
        code = [list[x:x + 8] for x in range(0, len(list), 8)]
        clist.append((c,code))

    dictionary = dict(clist)
    return dictionary

def displayObject(obj, x, y):
    global pixel
    lcd.clear()
    xp = x
    for y1 in obj:
        for x2 in y1:
            if x2 == 1:
                pixel = 1
            else:
                pixel = 0
            lcd.set_pixel(xp, y, pixel)
            xp += 1
        y += 1
        lcd.set_pixel(xp, y, pixel)

    lcd.show()



def displayObject(obj, x, y):
    lcd.clear()
    xp = x
    for y1 in obj:
        for x1 in y1:
            lenY = len(obj)
            lenX = len(y1)
            if x1 == 1:
                pixel = 1
            else:
                pixel = 0
            lcd.set_pixel(xp, y, pixel)
            xp += 1
        y += 1
        lcd.set_pixel(xp, y, pixel)
        xp = x
    lcd.show()


def clearScreen(lcd):
    lcd.clear()
    lcd.show()

def displayText(text,lcd,x,y):
    lcd.clear()
    width, height = lcd.dimensions()
    image = Image.new('P', (width, height))
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype(fonts.AmaticSCBold, 24)
    w, h = font.getsize(text)
    draw.text((x,y), text, 1, font)
    for x1 in range(x,x+w):
        for y1 in range(y,y+h):
            pixel = image.getpixel((x1, y1))
            lcd.set_pixel(x1, y1, pixel)
            lcd.show()



def hex2bin(hexValue):
    hexValueList = list(hexValue[2:])
    binValueList = []
    for i in hexValueList:
        binValue = bin(int(i, 16))[2:].zfill(4)
        binValueList.append(binValue)
    binValue = ''.join(binValueList)
    return binValue


def bitmapInHat():
    chars = generateDictionary()
    print('Please press a key: ')
    c = click.getchar()
    print(c)
    n = 0
    for key in chars.keys():
        if key == c:
            clearScreen(lcd)
            binValue = chars[key]
            displayObject(binValue, 2, 2)
            n = 1
            break
    if n == 0:
        msg = "You input isn't recorded in the dictionary."
        clearScreen(lcd)
        displayText(msg, lcd, 2, 10)
        print(msg)


bitmapInHat()




