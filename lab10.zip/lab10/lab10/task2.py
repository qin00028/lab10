import csv

f = input("File name:")
file = open(f)
file.read
while True:
    line = file.readline()
    print(line)
    if line == "":
        break

print(line)
file.close()





